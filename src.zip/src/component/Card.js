import React from "react";

export default function Card({src,title,discription,price}){
    return(
        <div className="my-2 mx-2" style={{border:'5px solid black'}}>
            <div className="img" > 
                <img src={src} width='150px' />
            </div>

            <div className="title">
                {title}
            </div>

            <div className="discpriton" >
                {discription}
            </div>

            <div className="price">
                {price}
            </div>


        </div>
    )
}